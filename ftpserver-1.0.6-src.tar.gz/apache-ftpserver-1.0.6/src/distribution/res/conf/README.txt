You can find two sample configuration files here. One is a typical
configuration file containing the common settings. The other is a full-fledged
configuration file showing all available parameters.